import Image from "next/image"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Textarea } from "@/components/ui/textarea"
import { Accordion, AccordionContent, AccordionItem, AccordionTrigger } from "@/components/ui/accordion"

export default function LandingPage() {
  return (
    <div className="flex flex-col min-h-screen">
      <header className="bg-white shadow-sm">
        <div className="container mx-auto px-4 py-4 flex justify-between items-center">
          <div className="flex items-center space-x-2">
            <Image
              src="/images/logo.png"
              alt="Modern Sit Dog Care Logo"
              width={50}
              height={50}
              className="h-12 w-auto"
            />
          </div>
          <nav>
            <ul className="flex space-x-4">
              <li>
                <a href="#about" className="text-gray-600 hover:text-blue-600">
                  About
                </a>
              </li>
              <li>
                <a href="#experience" className="text-gray-600 hover:text-blue-600">
                  Experience
                </a>
              </li>
              <li>
                <a href="#testimonials" className="text-gray-600 hover:text-blue-600">
                  Testimonials
                </a>
              </li>
              <li>
                <a href="#faq" className="text-gray-600 hover:text-blue-600">
                  FAQ
                </a>
              </li>
              <li>
                <a href="#contact" className="text-gray-600 hover:text-blue-600">
                  Contact
                </a>
              </li>
            </ul>
          </nav>
        </div>
      </header>

      <main className="flex-grow">
        <section className="bg-blue-50 py-20">
          <div className="container mx-auto px-4 text-center">
            <h1 className="text-4xl md:text-5xl font-bold text-gray-800 mb-4">Your Trusted House and Dog Sitters</h1>
            <p className="text-xl text-gray-600 mb-8">
              A husband-wife team with professional experience and a passion for pet care.
            </p>
            <Button size="lg" className="mb-8">
              Book a Free Consultation
            </Button>
            <div className="grid md:grid-cols-3 gap-8 mt-12">
              <Image
                src="https://hebbkx1anhila5yf.public.blob.vercel-storage.com/image-LxL41wErv3k93QHvvfx5kuPwoxQe1W.png"
                alt="Dog sitting experience"
                width={400}
                height={300}
                className="rounded-lg shadow-lg"
              />
              <Image
                src="https://hebbkx1anhila5yf.public.blob.vercel-storage.com/image-U9ldJnXHFSRFTsi6lIa3YgzheidOmQ.png"
                alt="Professional dog care with multiple breeds"
                width={300}
                height={400}
                className="rounded-lg shadow-lg"
              />
              <Image
                src="https://hebbkx1anhila5yf.public.blob.vercel-storage.com/image-g1Q43x5G9VaYvjGeyhSDj53xUVp0gq.png"
                alt="Outdoor adventures with dogs"
                width={400}
                height={300}
                className="rounded-lg shadow-lg"
              />
            </div>
          </div>
        </section>

        <section id="experience" className="py-20">
          <div className="container mx-auto px-4">
            <h2 className="text-3xl font-bold text-center mb-12">Our Experience</h2>
            <div className="grid md:grid-cols-2 gap-12 items-center">
              <div className="space-y-6">
                <h3 className="text-2xl font-semibold">Professional Dog Care Experience</h3>
                <p className="text-gray-600">
                  Our team brings 3+ years of professional dog-walking experience, caring for dogs of all ages and
                  sizes:
                </p>
                <ul className="list-disc list-inside space-y-2 text-gray-600">
                  <li>Puppies as young as 13 weeks to seniors up to 13 years</li>
                  <li>Small breeds like French Bulldogs and Pom-Yorkies</li>
                  <li>Large breeds including Great Danes and Giant Schnauzers</li>
                  <li>Special experience with pitbulls (we love them!)</li>
                  <li>Hundreds of nights of house-sitting experience</li>
                </ul>
              </div>
              <div className="grid grid-cols-2 gap-4">
                <Image
                  src="https://hebbkx1anhila5yf.public.blob.vercel-storage.com/image-z8XHha9ABO9Igda91unD834nTCYoTg.png"
                  alt="Happy dog care"
                  width={300}
                  height={400}
                  className="rounded-lg shadow-lg"
                />
                <Image
                  src="https://hebbkx1anhila5yf.public.blob.vercel-storage.com/image-VsA73l1rVS5Kmssc6Rbc5ExavVRDRN.png"
                  alt="Professional dog care"
                  width={300}
                  height={400}
                  className="rounded-lg shadow-lg"
                />
              </div>
            </div>
          </div>
        </section>

        <section id="faq" className="bg-gray-50 py-20">
          <div className="container mx-auto px-4">
            <h2 className="text-3xl font-bold text-center mb-12">Frequently Asked Questions</h2>
            <div className="max-w-3xl mx-auto">
              <Accordion type="single" collapsible>
                <AccordionItem value="item-1">
                  <AccordionTrigger>Why do you require a consultation before booking?</AccordionTrigger>
                  <AccordionContent>
                    We believe in ensuring the perfect match between sitters and pets. The consultation allows us to
                    meet your dogs, understand their needs and routines, and make sure we're the right fit for your
                    family.
                  </AccordionContent>
                </AccordionItem>
                <AccordionItem value="item-2">
                  <AccordionTrigger>What's included in your house-sitting service?</AccordionTrigger>
                  <AccordionContent>
                    Our service includes daily dog walks, feeding, medication administration if needed, house
                    maintenance, plant watering, mail collection, and regular updates with photos of your pets.
                  </AccordionContent>
                </AccordionItem>
                <AccordionItem value="item-3">
                  <AccordionTrigger>How long can you stay at our home?</AccordionTrigger>
                  <AccordionContent>
                    We're flexible with duration and can accommodate both short weekend trips and extended vacations of
                    several weeks.
                  </AccordionContent>
                </AccordionItem>
                <AccordionItem value="item-4">
                  <AccordionTrigger>Are you insured and bonded?</AccordionTrigger>
                  <AccordionContent>
                    Yes, we maintain comprehensive insurance coverage for both pet care and house-sitting services for
                    your peace of mind.
                  </AccordionContent>
                </AccordionItem>
                <AccordionItem value="item-5">
                  <AccordionTrigger>What happens in case of a pet emergency?</AccordionTrigger>
                  <AccordionContent>
                    During the initial consultation, we'll collect emergency contact information, your vet's details,
                    and discuss emergency protocols. We'll also establish whether we're authorized to charge your credit
                    card on file for any veterinary procedures not covered by pet insurance. This ensures we can act
                    quickly and according to your wishes if any emergency arises.
                  </AccordionContent>
                </AccordionItem>
                <AccordionItem value="item-6">
                  <AccordionTrigger>How do you handle updates during our absence?</AccordionTrigger>
                  <AccordionContent>
                    We create a dedicated WhatsApp group chat with you where we share daily photos, videos, and updates
                    about your pets and home. This ensures easy, real-time communication and allows you to stay
                    connected with your pets throughout your time away.
                  </AccordionContent>
                </AccordionItem>
              </Accordion>
            </div>
          </div>
        </section>

        <section id="contact" className="py-20">
          <div className="container mx-auto px-4">
            <h2 className="text-3xl font-bold text-center mb-12">Book Your Free Consultation</h2>
            <div className="max-w-2xl mx-auto">
              <form className="space-y-6">
                <div className="grid md:grid-cols-2 gap-4">
                  <div>
                    <label className="block text-sm font-medium mb-2">Name</label>
                    <Input type="text" placeholder="Your name" required />
                  </div>
                  <div>
                    <label className="block text-sm font-medium mb-2">Email</label>
                    <Input type="email" placeholder="Your email" required />
                  </div>
                </div>
                <div className="grid md:grid-cols-2 gap-4">
                  <div>
                    <label className="block text-sm font-medium mb-2">Phone</label>
                    <Input type="tel" placeholder="Your phone number" required />
                  </div>
                  <div>
                    <label className="block text-sm font-medium mb-2">Preferred Dates</label>
                    <Input type="text" placeholder="When do you need sitting?" required />
                  </div>
                </div>
                <div>
                  <label className="block text-sm font-medium mb-2">Tell us about your pets</label>
                  <Textarea
                    placeholder="Number of pets, breeds, ages, and any special care requirements"
                    className="min-h-[100px]"
                    required
                  />
                </div>
                <div className="text-center">
                  <Button type="submit" size="lg">
                    Request Consultation
                  </Button>
                </div>
              </form>
              <p className="text-sm text-muted-foreground mt-8 text-center">
                Note: Due to allergies, we are currently only able to provide care for dogs.
              </p>
            </div>
          </div>
        </section>
      </main>

      <footer className="bg-gray-800 text-white py-8">
        <div className="container mx-auto px-4 flex flex-col items-center space-y-4">
          <Image src="/images/logo.png" alt="Modern Sit Dog Care Logo" width={60} height={60} className="h-16 w-auto" />
          <p>&copy; 2025 ModernSit: A Modern Problem-Solvers Service. All rights reserved.</p>
        </div>
      </footer>
    </div>
  )
}

